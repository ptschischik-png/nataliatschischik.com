<!DOCTYPE html>
<html lang="de">
<head>
<!--
-->


<meta charset="utf-8">
<!-- Google tag (gtag.js) -->
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('consent', 'default', {
    'ad_storage': 'granted',
    'ad_user_data': 'granted',
    'ad_personalization': 'granted',
    'analytics_storage': 'granted'
  });
</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-4WTB03GDRG"></script>
<script>
  gtag('js', new Date());
  gtag('config', 'G-4WTB03GDRG', {
    'allow_enhanced_conversions': true
  });
</script>
<meta name="google-site-verification" content="VdwJ2n6jCGWsFH_AE7-wwXYc8crrWTDp-kNba3mWOP4" />
<meta name="facebook-domain-verification" content="5e2jspggv55xycs247egl8diamhup4" />
<meta name="apple-domain-verification" content="A4Lq3sdot5vt-8ubmaLnH3czieipD2VbFth9KijInbI" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" href="favicon.ico" sizes="32x32">
<link rel="icon" href="favicon.svg.html" type="image/svg+xml">
<link rel="apple-touch-icon" href="apple-touch-icon.png.html">
<title>Hochzeitsfotograf Kassel — Natalia Tschischik</title>
<meta name="description" content="Hochzeitsfotografin in Kassel. 10+ Jahre Erfahrung, 200+ Paare, 4.8 Google-Sterne. Zeitlose Hochzeitsreportagen voller Emotionen.">
<meta name="keywords" content="Hochzeitsfotograf Kassel, Hochzeitsfotografin Kassel, Hochzeitsfotograf Göttingen, Hochzeitsfotograf Kassel Preis, Hochzeitsreportage Kassel, Hochzeitsfotografie Nordhessen, Brautpaar Fotograf Kassel">
<meta property="og:title" content="Hochzeitsfotograf Kassel — Natalia Tschischik">
<meta property="og:description" content="Hochzeitsfotografin in Kassel. 10+ Jahre Erfahrung, 200+ Paare. Zeitlose Hochzeitsreportagen.">
<meta property="og:type" content="website">
<meta property="og:locale" content="de_DE">
<link rel="canonical" href="index.html">
<link rel="alternate" hreflang="de" href="index.html">
<link rel="alternate" hreflang="x-default" href="index.html">
<meta name="robots" content="index, follow">
<meta name="geo.region" content="DE-HE">
<meta name="geo.placename" content="Kassel">

<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "Photographer"],
  "@id": "https://nataliatschischik.com",
  "name": "Hochzeitsfotograf Natalia Tschischik",
  "alternateName": "Natalia Tschischik Photography",
  "description": "Hochzeitsfotograf in Kassel und Göttingen. Emotionale Hochzeitsreportagen, die sich anfühlen wie ein Film aus eurem schönsten Tag. 10+ Jahre Erfahrung, über 200 Paare begleitet.",
  "url": "https://nataliatschischik.com",
  "telephone": "+49 176 34948598",
  "hasMap": "https://maps.app.goo.gl/ak2VVrbKNQpdYCc16?g_st=ic",
  "email": "natalia@nataliatschischik.com",
  "image": "/img/ext/gd-15zAiT52byizm3F-.webp",
  "priceRange": "€€",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Harleshäuser Str. 38",
    "addressLocality": "Vellmar",
    "postalCode": "34246",
    "addressRegion": "Hessen",
    "addressCountry": "DE"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 51.3127,
    "longitude": 9.4797
  },
  "areaServed": [
    { "@type": "City", "name": "Kassel" },
    { "@type": "City", "name": "Göttingen" },
    { "@type": "City", "name": "Marburg" },
    { "@type": "City", "name": "Gießen" },
    { "@type": "City", "name": "Fulda" },
    { "@type": "City", "name": "Frankenberg" },
    { "@type": "AdministrativeArea", "name": "Nordhessen" },
    { "@type": "AdministrativeArea", "name": "Waldeck-Frankenberg" },
    { "@type": "AdministrativeArea", "name": "Hessen" },
    { "@type": "AdministrativeArea", "name": "Niedersachsen" }
  ],
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "bestRating": "5",
    "reviewCount": "40"
  },
  "review": [
    {
      "@type": "Review",
      "author": {"@type": "Person", "name": "Julia & Marc"},
      "datePublished": "2024-09-15",
      "reviewBody": "Natalia hat unseren Tag in Bilder gefasst, die wir selbst nicht gesehen haben. Den Moment, als mein Vater mir den Brautstrauß gereicht hat. Die Träne meiner Schwester während der Trauung. Jedes Mal, wenn wir das Album öffnen, sind wir wieder dort.",
      "reviewRating": {"@type": "Rating", "ratingValue": "5", "bestRating": "5"}
    },
    {
      "@type": "Review",
      "author": {"@type": "Person", "name": "Sophie & Christian"},
      "datePublished": "2024-06-22",
      "reviewBody": "Wir hatten richtig Angst vor gestellten Fotos. Natalia hat uns gesagt: Vergesst die Kamera. Das haben wir. Und die Bilder sind unglaublich geworden — echt, leise, voller Gefühl. Genau wie unser Tag.",
      "reviewRating": {"@type": "Rating", "ratingValue": "5", "bestRating": "5"}
    }
  ],
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Hochzeitsreportagen",
    "itemListElement": [
      {
        "@type": "Offer",
        "name": "Standesamt-Reportage",
        "description": "Ab 3 Stunden Begleitung, min. 150 bearbeitete Bilder, An- & Abreise bis 50 km inklusive",
        "price": "500",
        "priceCurrency": "EUR"
      },
      {
        "@type": "Offer",
        "name": "Ganztags-Reportage",
        "description": "8–12 Stunden Begleitung, min. 400–600 bearbeitete Bilder, An- & Abreise bis 200 km inklusive",
        "price": "1400",
        "priceCurrency": "EUR"
      }
    ]
  },
  "sameAs": ["https://www.instagram.com/hochzeitsfotografin.natalia"]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Was kostet ein Hochzeitsfotograf in Kassel?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Hochzeitsreportagen bei Natalia Tschischik starten ab 500 € für eine Standesamtbegleitung. Ganztägige Reportagen gibt es ab 1.400 €. Eure Hochzeit ist einzigartig — euer Paket sollte es auch sein. Am besten einfach unverbindlich anfragen."
      }
    },
    {
      "@type": "Question",
      "name": "Wie weit im Voraus sollte man einen Hochzeitsfotografen in Kassel buchen?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Je früher, desto besser — besonders für Termine zwischen Mai und Oktober. Viele Paare melden sich 10–14 Monate vor der Hochzeit. Auch kurzfristige Anfragen sind willkommen, wenn das Datum noch frei ist."
      }
    },
    {
      "@type": "Question",
      "name": "Wann bekommt man die Hochzeitsfotos?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Innerhalb von 6–8 Wochen nach eurer Hochzeit erhaltet ihr eure private Online-Galerie mit allen bearbeiteten Bildern zum Download. Einen Sneak Peek mit den ersten Highlights bekommt ihr innerhalb von 48 Stunden."
      }
    },
    {
      "@type": "Question",
      "name": "Fotografiert Natalia auch außerhalb von Kassel?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Ja, Natalia fotografiert in ganz Hessen und Niedersachsen. Innerhalb von 200 km um Kassel ist die Anfahrt inklusive. Darüber hinaus kommen Fahrtkosten und ggf. eine Übernachtung dazu."
      }
    }
  ]
}
</script>

<!-- Fonts -->
<link rel="preload" as="image" type="image/webp" href="img/ext/gd-15zAiT52byizm3F--800w.webp.html" imagesrcset="/img/ext/gd-15zAiT52byizm3F--400w.webp 400w, /img/ext/gd-15zAiT52byizm3F--800w.webp 800w, /img/ext/gd-15zAiT52byizm3F-.webp 896w" imagesizes="(max-width: 768px) 100vw, 40vw" fetchpriority="high">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link rel="dns-prefetch" href="https://lh3.googleusercontent.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500;1,600&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500;1,600&family=DM+Sans:ital,wght@0,300;0,400;0,500;0,600;1,400&display=swap" rel="stylesheet"></noscript>

<style>
/* ═══ RESET ═══ */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; -webkit-font-smoothing: antialiased; scroll-padding-top: 5rem; }
img { display: block; max-width: 100%; height: auto; }
button, a { font: inherit; color: inherit; text-decoration: none; }
button { cursor: pointer; background: none; border: none; }
ul { list-style: none; }

/* ═══ CUSTOM PROPERTIES ═══ */
:root {
  --cream: #F5F0E8;
  --cream-light: #FAF8F4;
  --cream-dark: #EDE7DB;
  --white: #FDFCFA;
  --brown-900: #2C1810;
  --brown-800: #3D2518;
  --brown-700: #4A3228;
  --brown-600: #5E443A;
  --brown-500: #7A6258;
  --brown-400: #9E8A80;
  --brown-300: #C4B5AB;
  --brown-200: #DDD3CA;
  --brown-100: #EDE7E0;
  --accent: #5A2628;
  --accent-dark: #481E20;
  --accent-light: #835C5D;
  --dark-bg: #1E1B18;
  --dark-card: #2A2622;

  --font-display: 'Cormorant Garamond', 'Georgia', serif;
  --font-body: 'DM Sans', 'Helvetica Neue', sans-serif;

  --text-xs: clamp(0.6875rem, 0.65rem + 0.15vw, 0.75rem);
  --text-sm: clamp(0.8125rem, 0.78rem + 0.15vw, 0.875rem);
  --text-base: clamp(0.9375rem, 0.9rem + 0.2vw, 1rem);
  --text-lg: clamp(1.0625rem, 1rem + 0.4vw, 1.25rem);
  --text-xl: clamp(1.375rem, 1.1rem + 0.8vw, 1.75rem);
  --text-2xl: clamp(1.75rem, 1.3rem + 1.5vw, 2.75rem);
  --text-3xl: clamp(2.25rem, 1.5rem + 2.5vw, 3.75rem);
  --text-hero: clamp(2.75rem, 1rem + 5.5vw, 5.5rem);
  --text-display: clamp(3.5rem, 1.5rem + 6vw, 7rem);

  --radius: 6px;
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --transition: 300ms var(--ease-out);
}

/* ═══ BASE ═══ */
body {
  font-family: var(--font-body);
  font-size: var(--text-base);
  line-height: 1.65;
  color: var(--brown-600);
  background: var(--cream);
}

h1, h2, h3, h4 {
  font-family: var(--font-display);
  font-weight: 400;
  line-height: 1.1;
  color: var(--brown-900);
}

p { max-width: 60ch; }

::selection {
  background: rgba(74, 93, 58, 0.18);
  color: var(--brown-900);
}

/* ═══ NAV ═══ */
.nav {
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  padding: 1.25rem clamp(1.5rem, 3vw, 3rem);
  display: flex; justify-content: space-between; align-items: center;
  background: rgba(245, 240, 232, 0.88);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-bottom: 1px solid rgba(0,0,0,0.04);
  transition: padding var(--transition), background var(--transition);
}
.nav.scrolled { padding: 0.75rem clamp(1.5rem, 3vw, 3rem); }
.nav-logo {
  font-family: var(--font-display);
  font-size: 1.5rem;
  font-style: italic;
  font-weight: 500;
  letter-spacing: -0.01em;
  color: var(--brown-900);
}
.nav-links { display: flex; gap: 2.25rem; align-items: center; }
.nav-links a {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--brown-500);
  transition: color var(--transition);
  position: relative;
}
.nav-links a:hover { color: var(--brown-900); }
.nav-links a::after {
  content: ''; position: absolute; bottom: -4px; left: 0;
  width: 0; height: 1px; background: var(--brown-900);
  transition: width var(--transition);
}
.nav-links a:hover::after { width: 100%; }
.nav-cta {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 0.625rem 1.5rem;
  background: var(--accent);
  color: var(--cream-light);
  border-radius: var(--radius);
  transition: background var(--transition);
}
.nav-cta:hover { background: var(--accent-dark); }

/* Mobile menu */
.hamburger {
  display: none; flex-direction: column; gap: 5px;
  width: 24px; padding: 0;
}
.hamburger span {
  display: block; height: 1.5px; background: var(--brown-900);
  transition: transform var(--transition), opacity var(--transition);
  transform-origin: center;
}
.hamburger.active span:nth-child(1) { transform: translateY(6.5px) rotate(45deg); }
.hamburger.active span:nth-child(2) { opacity: 0; }
.hamburger.active span:nth-child(3) { transform: translateY(-6.5px) rotate(-45deg); }

.nav-mobile {
  display: none; position: fixed; inset: 0; z-index: 99;
  background: var(--cream);
  flex-direction: column; justify-content: center; align-items: center; gap: 2rem;
}
.nav-mobile.open { display: flex; }
.nav-mobile a {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  font-style: italic;
  color: var(--brown-900);
  transition: color var(--transition);
}
.nav-mobile a:hover { color: var(--accent); }
.nav-mobile .mobile-cta {
  margin-top: 1rem;
  font-family: var(--font-body);
  font-style: normal;
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 0.875rem 2.5rem;
  background: var(--accent);
  color: var(--cream-light);
}

@media (max-width: 900px) {
  .nav-links, .nav-cta { display: none; }
  .hamburger { display: flex; }
}

/* ═══ HERO ═══ */
.hero {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 1fr;
  padding-top: 4.5rem;
}
.hero-content {
  display: flex; flex-direction: column; justify-content: center;
  padding: clamp(2rem, 5vw, 6rem);
  padding-right: clamp(2rem, 4vw, 4rem);
}
.hero-label {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--accent);
  margin-bottom: 1.5rem;
}
.hero h1 {
  font-size: var(--text-hero);
  font-weight: 300;
  letter-spacing: -0.03em;
  margin-bottom: 2rem;
  color: var(--brown-900);
}
.hero h1 em {
  font-style: italic;
  font-weight: 400;
  color: var(--accent);
}
.hero-text {
  font-size: var(--text-base);
  color: var(--brown-500);
  margin-bottom: 2.5rem;
  line-height: 1.8;
}
.hero-cta-row { display: flex; gap: 1.25rem; align-items: center; flex-wrap: wrap; }
.btn-primary {
  display: inline-block;
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  padding: 1rem 2.5rem;
  background: var(--accent);
  color: var(--cream-light);
  border-radius: var(--radius);
  transition: background var(--transition), transform 0.2s ease;
}
.btn-primary:hover { background: var(--accent-dark); transform: translateY(-1px); }
.btn-ghost {
  display: inline-block;
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  padding: 1rem 2rem;
  border: 1px solid var(--brown-300);
  color: var(--brown-600);
  border-radius: var(--radius);
  transition: all var(--transition);
}
.btn-ghost:hover { border-color: var(--brown-900); color: var(--brown-900); }
.hero-image {
  position: relative; overflow: hidden;
}
.hero-image img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 8s ease;
}
.hero-image:hover img { transform: scale(1.03); }

@media (max-width: 768px) {
  .hero {
    grid-template-columns: 1fr;
    min-height: auto;
  }
  .hero-image { height: 65vh; order: -1; }
  .hero-content { padding: 2rem 1.5rem 3rem; }
}

/* ═══ TRUST BAR ═══ */
.trust-bar {
  display: flex; justify-content: center; align-items: center; gap: clamp(2rem, 4vw, 4rem);
  padding: 1.75rem 2rem;
  background: var(--white);
  border-top: 1px solid rgba(0,0,0,0.04);
  border-bottom: 1px solid rgba(0,0,0,0.04);
  flex-wrap: wrap;
}
.trust-item {
  display: flex; align-items: baseline; gap: 0.5rem;
}
.trust-number {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  font-weight: 500;
  color: var(--accent);
}
.trust-label {
  font-size: var(--text-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--brown-400);
}
.trust-divider {
  width: 1px; height: 24px; background: var(--brown-200);
}
.trust-highlight {
  background: var(--accent, #5A2628);
  color: var(--cream-light, #FAF8F4);
  padding: 0.5rem 1rem;
  border-radius: 4px;
  gap: 0.4rem;
}
.trust-highlight .trust-number {
  color: var(--cream-light, #FAF8F4);
}
.trust-highlight .trust-label {
  color: rgba(250,248,244,0.8);
}
@media (max-width: 600px) {
  .trust-divider { display: none; }
  .trust-bar {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.25rem 0;
    padding: 1.5rem 1.5rem;
  }
  .trust-item { justify-content: center; }
}

/* ═══ SECTION UTILITIES ═══ */
.section {
  padding: clamp(6rem, 12vw, 11rem) clamp(1.5rem, 5vw, 6rem);
}
.section-label {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--accent);
  margin-bottom: 1rem;
  display: block;
}
.section-title {
  font-size: var(--text-2xl);
  font-weight: 300;
  margin-bottom: 2rem;
  letter-spacing: -0.02em;
}
.section-title em {
  font-style: italic;
  font-weight: 400;
}
.container { max-width: 1140px; margin: 0 auto; }

}

/* ═══ PORTFOLIO ═══ */
.portfolio { background: var(--cream); }
.portfolio-header {
  display: flex; justify-content: space-between; align-items: flex-end;
  margin-bottom: 4rem; flex-wrap: wrap; gap: 1rem;
}
.portfolio-header h2 {
  font-style: italic;
}
/* Portfolio Cards */
.pf-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}
.pf-card {
  text-decoration: none;
  color: inherit;
  display: block;
  transition: transform 0.4s var(--ease-out);
}
.pf-card:hover { transform: translateY(-4px); }
.pf-card-img {
  position: relative;
  overflow: hidden;
  aspect-ratio: 3/4;
  border-radius: 4px;
}
.pf-card-img img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform 0.8s var(--ease-out);
}
.pf-card:hover .pf-card-img img { transform: scale(1.04); }
.pf-card-info {
  padding: 1rem 0.25rem 0;
}
.pf-card-info h3 {
  font-family: var(--font-display);
  font-size: var(--text-xl);
  font-weight: 400;
  color: var(--brown-900);
  margin-bottom: 0.15rem;
}
.pf-card-info p {
  font-size: var(--text-xs);
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--brown-400);
  margin-bottom: 0.6rem;
}
.pf-card-link {
  font-size: 0.65rem;
  font-weight: 600;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--accent, #5A2628);
  border-bottom: 1px solid currentColor;
  padding-bottom: 2px;
  transition: opacity 0.3s;
}
.pf-card:hover .pf-card-link { opacity: 0.7; }

@media (max-width: 768px) {
  .pf-grid { grid-template-columns: 1fr; gap: 2.5rem; }
  .pf-card-img { aspect-ratio: 4/5; }
  .pf-card-info { padding: 0.75rem 0 0; }
}

/* ═══ TESTIMONIALS ═══ */
.testimonials {
  background: var(--dark-bg);
  color: var(--cream);
  position: relative;
  overflow: hidden;
}
.testimonials-deco {
  position: absolute;
  font-family: var(--font-display);
  font-size: clamp(12rem, 25vw, 28rem);
  color: rgba(255,255,255,0.025);
  line-height: 1;
  pointer-events: none;
  top: -2rem;
  left: 50%;
  transform: translateX(-50%);
}
.testimonials-header {
  text-align: center;
  margin-bottom: 3.5rem;
  position: relative;
}
.testimonials-header .section-label { color: var(--brown-400); }
.testimonials-header h2 {
  color: var(--cream);
  font-style: italic;
}
.testimonial-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2.5rem;
  max-width: 1100px;
  margin: 0 auto;
  position: relative;
}
.testimonial-featured {
  grid-column: 1 / -1;
  text-align: left;
  max-width: 700px;
  margin: 0 auto;
}
.testimonial-card {
  background: var(--dark-card);
  padding: 2.5rem 2rem;
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: var(--radius);
  display: flex; flex-direction: column;
}
.testimonial-deco-mark {
  font-family: var(--font-display);
  font-size: 3.5rem;
  line-height: 1;
  color: var(--accent-light);
  margin-bottom: 0.75rem;
}
.testimonial-quote {
  font-family: var(--font-display);
  font-size: var(--text-lg);
  font-style: italic;
  font-weight: 400;
  color: var(--cream);
  line-height: 1.55;
  flex: 1;
  margin-bottom: 1.75rem;
  max-width: none;
  opacity: 0.9;
}
.testimonial-author {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--brown-400);
}
.testimonial-detail {
  font-size: var(--text-xs);
  color: var(--brown-500);
  margin-top: 0.25rem;
}
.testimonials-stars {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  margin-top: 3rem;
  position: relative;
}
.testimonials-stars svg {
  width: 18px; height: 18px;
  fill: var(--accent-light);
}
.testimonials-rating {
  text-align: center;
  margin-top: 0.75rem;
  font-size: var(--text-xs);
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--brown-500);
  position: relative;
  max-width: none;
}

@media (max-width: 768px) {
  .testimonial-grid { grid-template-columns: 1fr; max-width: 500px; }
}

/* ═══ ABOUT ═══ */
.about {
  background: var(--cream-light);
}
.about-grid {
  display: grid;
  grid-template-columns: 5fr 7fr;
  gap: clamp(3rem, 6vw, 8rem);
  align-items: center;
}
.about-image {
  position: relative;
  overflow: hidden;
  border-radius: 2px;
}
.about-image img {
  width: 100%; height: auto;
  aspect-ratio: 3/4;
  object-fit: cover;
}
.about-content { max-width: 520px; }
.about-content h2 {
  font-size: var(--text-3xl);
  font-style: italic;
  font-weight: 300;
  margin-bottom: 1.75rem;
}
.about-content p {
  margin-bottom: 1.25rem;
  color: var(--brown-500);
  line-height: 1.8;
}
.about-signature {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--text-xl);
  color: var(--brown-800);
  margin-top: 2rem;
}

@media (max-width: 768px) {
  .about-grid { grid-template-columns: 1fr; }
  .about-image { max-width: 400px; }
}

/* ═══ PROCESS ═══ */
.process { background: var(--cream); }
.process-header {
  text-align: center;
  margin-bottom: 4rem;
}
.process-header h2 { font-style: italic; }
.process-steps {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 3rem;
  max-width: 960px;
  margin: 0 auto;
}
.process-step {
  text-align: center;
  padding: 2rem 1.5rem;
  background: var(--cream-light);
  border: 1px solid rgba(0,0,0,0.04);
  border-radius: var(--radius);
}
.process-number {
  font-family: var(--font-display);
  font-size: var(--text-display);
  font-weight: 300;
  color: var(--brown-200);
  line-height: 1;
  margin-bottom: 1rem;
}
.process-step h4 {
  font-size: var(--text-xl);
  font-style: italic;
  margin-bottom: 0.75rem;
}
.process-step p {
  font-size: var(--text-sm);
  color: var(--brown-500);
  max-width: 28ch;
  margin: 0 auto;
  line-height: 1.7;
}

@media (max-width: 600px) {
  .process-steps { grid-template-columns: 1fr; gap: 1.5rem; }
}

/* ═══ FAQ ═══ */
.faq { background: var(--cream-light); }
.faq-header {
  text-align: center;
  margin-bottom: 3rem;
}
.faq-header h2 { font-style: italic; }
.faq-list {
  max-width: 760px;
  margin: 0 auto;
}
.faq-item {
  border-bottom: 1px solid var(--brown-200);
}
.faq-question {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 0;
  font-family: var(--font-display);
  font-size: var(--text-lg);
  font-weight: 400;
  color: var(--brown-900);
  text-align: left;
  transition: color var(--transition);
  gap: 1rem;
}
.faq-question:hover { color: var(--accent); }
.faq-icon {
  width: 24px; height: 24px; flex-shrink: 0;
  position: relative;
  transition: transform var(--transition);
}
.faq-icon::before, .faq-icon::after {
  content: '';
  position: absolute;
  background: var(--brown-400);
  transition: transform var(--transition), opacity var(--transition);
}
.faq-icon::before {
  width: 14px; height: 1.5px;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
}
.faq-icon::after {
  width: 1.5px; height: 14px;
  top: 50%; left: 50%;
  transform: translate(-50%, -50%);
}
.faq-item.open .faq-icon::after {
  transform: translate(-50%, -50%) rotate(90deg);
  opacity: 0;
}
.faq-answer {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s var(--ease-out), padding 0.4s var(--ease-out);
}
.faq-answer-inner {
  padding-bottom: 1.5rem;
  font-size: var(--text-sm);
  color: var(--brown-500);
  line-height: 1.8;
  max-width: 60ch;
}

/* ═══ CONTACT ═══ */
.contact {
  background: var(--cream);
}
.contact-inner {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: clamp(3rem, 6vw, 6rem);
  align-items: start;
}
.contact-left h2 {
  font-size: var(--text-display);
  font-weight: 300;
  font-style: italic;
  line-height: 0.95;
  letter-spacing: -0.04em;
  margin-bottom: 2rem;
}
.contact-desc {
  color: var(--brown-500);
  line-height: 1.8;
  margin-bottom: 2.5rem;
}
.contact-info {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.contact-info-item {
  display: flex; align-items: center; gap: 0.75rem;
  font-size: var(--text-sm);
  color: var(--brown-600);
}
.contact-info-item svg {
  width: 18px; height: 18px;
  stroke: var(--accent);
  fill: none;
  stroke-width: 1.5;
  flex-shrink: 0;
}
.contact-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}
.form-group { display: flex; flex-direction: column; gap: 0.375rem; }
.form-group label {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--brown-500);
}
.form-group input,
.form-group textarea,
.form-group select {
  font-family: var(--font-body);
  font-size: var(--text-sm);
  padding: 0.875rem 1rem;
  background: var(--cream-light);
  border: 1px solid var(--brown-200);
  border-radius: var(--radius);
  color: var(--brown-900);
  transition: border-color var(--transition);
  outline: none;
  width: 100%;
}
.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  border-color: var(--accent);
}
.form-group textarea { resize: vertical; min-height: 120px; }
.form-group select {
  -webkit-appearance: none;
  appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='7' fill='none'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%237A6258' stroke-width='1.5'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  padding-right: 2.5rem;
}
.form-submit {
  font-size: var(--text-xs);
  font-weight: 500;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  padding: 1.125rem 2.5rem;
  background: var(--accent);
  color: var(--cream-light);
  border: none;
  border-radius: var(--radius);
  cursor: pointer;
  transition: background var(--transition), transform 0.2s ease;
  align-self: flex-start;
  margin-top: 0.5rem;
}
.form-submit:hover { background: var(--accent-dark); transform: translateY(-1px); }

@media (max-width: 768px) {
  .contact-inner { grid-template-columns: 1fr; }
  .form-row { grid-template-columns: 1fr; }
}

/* ═══ FOOTER ═══ */
.footer {
  background: var(--dark-bg);
  color: var(--brown-400);
  padding: 4rem clamp(1.5rem, 5vw, 6rem) 2rem;
}
.footer-inner {
  max-width: 1240px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-wrap: wrap;
  gap: 2rem;
}
.footer-brand {
  font-family: var(--font-display);
  font-style: italic;
  font-size: var(--text-xl);
  color: var(--cream);
  margin-bottom: 0.5rem;
}
.footer-tagline {
  font-size: var(--text-xs);
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--brown-500);
  max-width: 280px;
  line-height: 1.6;
}
.footer-links { display: flex; gap: 3rem; }
.footer-col h5 {
  font-size: var(--text-xs);
  font-family: var(--font-body);
  font-weight: 500;
  letter-spacing: 0.12em;
  text-transform: uppercase;
  color: var(--brown-300);
  margin-bottom: 0.75rem;
}
.footer-col a {
  display: block;
  font-size: var(--text-sm);
  color: var(--brown-500);
  margin-bottom: 0.375rem;
  transition: color var(--transition);
}
.footer-col a:hover { color: var(--cream); }
.footer-bottom {
  max-width: 1240px;
  margin: 3rem auto 0;
  padding-top: 1.5rem;
  border-top: 1px solid rgba(255,255,255,0.06);
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 1rem;
}
@media (max-width: 768px) {
  .footer-inner { flex-direction: column; }
  .footer-links { flex-wrap: wrap; gap: 1.5rem 2rem; }
  .footer-col { min-width: 120px; }
  .footer-bottom { flex-direction: column; text-align: center; }
}
.footer-copy {
  font-size: var(--text-xs);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--brown-500);
}
.footer-bottom a {
  font-size: var(--text-xs);
  color: var(--brown-500);
  transition: color var(--transition);
}
.footer-bottom a:hover { color: var(--cream); }

/* ═══ ANIMATIONS ═══ */
.reveal {
  opacity: 0;
  transform: translateY(28px);
  transition: opacity 0.8s var(--ease-out), transform 0.8s var(--ease-out);
}
.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}
.reveal-delay-1 { transition-delay: 0.1s; }
.reveal-delay-2 { transition-delay: 0.2s; }
.reveal-delay-3 { transition-delay: 0.3s; }
</style>
<link rel="sitemap" type="application/xml" href="sitemap.xml">
<meta property="og:url" content="https://nataliatschischik.com/">
<meta property="og:image" content="https://nataliatschischik.com/images/og-default.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@natalia_photography">
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1083293176093427', {}, {autoConfig: true, autoAdvancedMatching: true});
fbq('track', 'PageView');
// Capture fbclid + gclid from URL and store in cookies
(function(){
  var params = new URLSearchParams(window.location.search);
  var fbclid = params.get('fbclid');
  if (fbclid) {
    var fbc = 'fb.1.' + Date.now() + '.' + fbclid;
    document.cookie = '_fbc=' + fbc + ';max-age=7776000;path=/;SameSite=Lax';
  }
  // Google Ads Click ID - persist for conversion attribution
  var gclid = params.get('gclid');
  if (gclid) {
    document.cookie = '_gclid=' + gclid + ';max-age=7776000;path=/;SameSite=Lax';
  }
  // Store landing page + UTM params for lead attribution
  if (params.get('utm_source') || gclid || fbclid) {
    var attribution = JSON.stringify({
      source: params.get('utm_source') || (gclid ? 'google' : fbclid ? 'meta' : ''),
      medium: params.get('utm_medium') || (gclid ? 'cpc' : fbclid ? 'cpc' : ''),
      campaign: params.get('utm_campaign') || '',
      landing: window.location.pathname,
      ts: Date.now()
    });
    document.cookie = '_attribution=' + encodeURIComponent(attribution) + ';max-age=7776000;path=/;SameSite=Lax';
  }
})();
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1083293176093427&ev=PageView&noscript=1"/></noscript>
<!-- End Meta Pixel Code -->
</head>

<body>

<!-- ═══ NAVIGATION ═══ -->
<nav class="nav" id="nav" role="navigation" aria-label="Hauptnavigation">
  <a href="tracking.js.html#" class="nav-logo">Natalia Tschischik</a>
  <div class="nav-links">
    <a href="portfolio.html">Portfolio</a>
    <a href="ueber-mich.html">Über mich</a>
    <a href="preise.html">Preise</a>
    <a href="faq.html">FAQ</a>
    <a href="journal.html">Journal</a>
    <a href="tracking.js.html#contact">Kontakt</a>
  </div>
  <a href="tracking.js.html#contact" class="nav-cta">Anfrage</a>
  <button class="hamburger" id="hamburger" aria-label="Menü öffnen">
    <span></span><span></span><span></span>
  </button>
</nav>

<div class="nav-mobile" id="mobileNav">
  <a href="portfolio.html" onclick="closeMobile()">Portfolio</a>
  <a href="ueber-mich.html" onclick="closeMobile()">Über mich</a>
  <a href="preise.html" onclick="closeMobile()">Preise</a>
  <a href="faq.html" onclick="closeMobile()">FAQ</a>
  <a href="journal.html" onclick="closeMobile()">Journal</a>
  <a href="tracking.js.html#contact" class="mobile-cta" onclick="closeMobile()">Anfrage senden</a>
</div>

<!-- ═══ HERO ═══ -->
<section class="hero" aria-label="Willkommen">
  <div class="hero-content">
    <span class="hero-label">Hochzeitsfotografie &middot; Kassel &amp; Göttingen</span>
    <h1>Eure Hochzeitsfotografin <br>in <em><span id="city-rotate">Kassel</span>.</em></h1>
    <p class="hero-label" style="margin-top: -0.5rem; margin-bottom: 1.5rem; font-size: var(--text-xs); letter-spacing: 0.15em; text-transform: uppercase; color: var(--brown-400);">Einmal. Für immer. Euer Tag.</p>
    <p class="hero-text">
      Als Hochzeitsfotografin in Kassel halte ich seit 2012 die Momente fest, die man nicht wiederholen kann — den Blick eures Vaters am Altar, das Lachen eurer besten Freundin, den Augenblick, in dem ihr euch anschaut und wisst: Das ist es.
    </p>
    <div class="hero-cta-row">
      <a href="tracking.js.html#contact" class="btn-primary">Termin prüfen</a>
      <a href="portfolio.html" class="btn-ghost">Reportagen ansehen</a>
    </div>
  </div>
  <div class="hero-image">
    <img src="img/ext/gd-15zAiT52byizm3F-.webp" srcset="img/ext/gd-15zAiT52byizm3F--400w.webp.html 400w, img/ext/gd-15zAiT52byizm3F--800w.webp.html 800w, img/ext/gd-15zAiT52byizm3F-.webp 896w" sizes="(max-width: 768px) 100vw, 40vw" alt="Portrait von Natalia Tschischik, Hochzeitsfotografin aus Kassel" fetchpriority="high" width="800" height="1000">
  </div>
</section>

<!-- ═══ TRUST BAR ═══ -->
<div class="trust-bar" aria-label="Vertrauensindikatoren">
  <div class="trust-item">
    <span class="trust-number">200+</span>
    <span class="trust-label">Paare begleitet</span>
  </div>
  <span class="trust-divider" aria-hidden="true"></span>
  <div class="trust-item">
    <span class="trust-number">10+</span>
    <span class="trust-label">Jahre Erfahrung</span>
  </div>
  <span class="trust-divider" aria-hidden="true"></span>
  <div class="trust-item">
    <span class="trust-number">4.8</span>
    <span class="trust-label">★ Google Bewertung</span>
  </div>
  <span class="trust-divider" aria-hidden="true"></span>
  <div class="trust-item trust-highlight">
    <span class="trust-number">200</span>
    <span class="trust-label">km Anfahrt inklusive</span>
  </div>
</div>


<!-- ═══ PORTFOLIO TEASER ═══ -->
<section class="section portfolio" id="portfolio" aria-label="Portfolio">
  <div class="container">
    <div class="portfolio-header reveal">
      <div>
        <span class="section-label">Ausgewählte Reportagen</span>
        <h2 class="section-title"><em>Hochzeitsreportagen, die sich <br>wie ein Film anfühlen.</em></h2>
      </div>
      <a href="portfolio.html" class="album-link">
        Alle Reportagen
        <svg viewBox="0 0 24 24" style="width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
    </div>
    <div class="pf-grid">
      <a href="reportagen/hochzeit-renthof-kassel-ra.html" class="pf-card reveal">
        <div class="pf-card-img">
          <img src="reportagen/img/ra-renthof/main-card.webp" alt="R &amp; A Hochzeit im Renthof Kassel — Erster Tanz" loading="lazy" width="1080" height="1318" srcset="reportagen/img/ra-renthof/main-card-400w.webp.html 400w, reportagen/img/ra-renthof/main-card-800w.webp.html 800w, reportagen/img/ra-renthof/main-card.webp 1080w" sizes="(max-width: 768px) 100vw, 50vw">
        </div>
        <div class="pf-card-info">
          <h3>R & A</h3>
          <p>Renthof Kassel</p>
          <span class="pf-card-link">Zur Reportage &rarr;</span>
        </div>
      </a>
      <a href="reportagen/hochzeit-goettingen.html" class="pf-card reveal">
        <div class="pf-card-img">
          <img src="reportagen/img/sg-goettingen/main-card.webp" alt="S &amp; G Hochzeit in Göttingen" loading="lazy" width="1012" height="1347" srcset="reportagen/img/sg-goettingen/main-card-400w.webp.html 400w, reportagen/img/sg-goettingen/main-card-800w.webp.html 800w, reportagen/img/sg-goettingen/main-card.webp 1012w" sizes="(max-width: 768px) 100vw, 50vw">
        </div>
        <div class="pf-card-info">
          <h3>S &amp; G</h3>
          <p>G&ouml;ttingen · Standesamt &amp; Kirche</p>
          <span class="pf-card-link">Zur Reportage &rarr;</span>
        </div>
      </a>
      <a href="reportagen/hochzeit-renthof-kassel.html" class="pf-card reveal">
        <div class="pf-card-img">
          <img src="img/ext/aw-portfolio-teaser.webp" srcset="img/ext/aw-portfolio-teaser-400w.webp.html 400w, img/ext/aw-portfolio-teaser-800w.webp.html 800w, img/ext/aw-portfolio-teaser.webp 1200w" sizes="(max-width: 768px) 100vw, 50vw" alt="Brautpaar im Renthof Kassel — A & W Hochzeitsreportage" loading="lazy">
        </div>
        <div class="pf-card-info">
          <h3>A & W</h3>
          <p>Renthof Kassel</p>
          <span class="pf-card-link">Zur Reportage &rarr;</span>
        </div>
      </a>
      <a href="reportagen/hochzeit-schloss-berlepsch.html" class="pf-card reveal">
        <div class="pf-card-img">
          <img src="reportagen/img/berlepsch/slider-card.webp" srcset="reportagen/img/berlepsch/slider-card-400w.webp.html 400w, reportagen/img/berlepsch/slider-card-800w.webp.html 800w, reportagen/img/berlepsch/slider-card.webp 901w" sizes="(max-width: 768px) 100vw, 50vw" alt="Brautpaar im Schloss Berlepsch — A & W Hochzeit Witzenhausen" loading="lazy">
        </div>
        <div class="pf-card-info">
          <h3>A & W</h3>
          <p>Schloss Berlepsch</p>
          <span class="pf-card-link">Zur Reportage &rarr;</span>
        </div>
      </a>


    </div>
    <div style="text-align: center; margin-top: 3rem;" class="reveal">
      <a href="portfolio.html" class="btn-ghost">Alle Reportagen ansehen</a>
    </div>
  </div>
</section>

<!-- ═══ TESTIMONIALS ═══ -->
<section class="section testimonials" id="testimonials" aria-label="Kundenstimmen">
  <span class="testimonials-deco" aria-hidden="true">&ldquo;</span>
  <div class="container">
    <div class="testimonials-header reveal">
      <span class="section-label">Das sagen meine Paare</span>
      <h2 class="section-title"><em>Worte, die mehr sagen <br>als jedes Bild.</em></h2>
    </div>
    <div class="testimonial-grid">
      <div class="testimonial-card reveal reveal-delay-1">
        <span class="testimonial-deco-mark" aria-hidden="true">&ldquo;</span>
        <p class="testimonial-quote">
          Wir sind beide relativ kamerascheu — abgesehen vom geplanten Paarshooting haben wir Natalia kaum bemerkt. Das hat enorm dazu beigetragen, dass sie natürliche und wunderschöne Fotos eingefangen hat.
        </p>
        <span class="testimonial-author">Willey</span>
        <span class="testimonial-detail">Google-Bewertung</span>
      </div>
      <div class="testimonial-card reveal reveal-delay-2">
        <span class="testimonial-deco-mark" aria-hidden="true">&ldquo;</span>
        <p class="testimonial-quote">
          Wir hätten uns keine bessere Fotografin als Natalia vorstellen können. Sie ist eine echte Künstlerin und arbeitet mit so viel Hingabe und Liebe, vom ersten Kontakt bis zur Begleitung an unserem besonderen Tag.
        </p>
        <span class="testimonial-author">Martin Malchow</span>
        <span class="testimonial-detail">Google-Bewertung</span>
      </div>
      <div class="testimonial-card reveal reveal-delay-3">
        <span class="testimonial-deco-mark" aria-hidden="true">&ldquo;</span>
        <p class="testimonial-quote">
          Ihre Leidenschaft für ihre Arbeit ist wirklich spürbar. Sie hat definitiv die schönsten Momente unseres besonderen Tages in ihren Fotos festgehalten.
        </p>
        <span class="testimonial-author">Karol Castillo</span>
        <span class="testimonial-detail">Google-Bewertung</span>
      </div>

    </div>
    <div class="testimonials-stars" aria-hidden="true">
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
    </div>
    <p class="testimonials-rating">4.8 Sterne bei Google &middot; 40+ Bewertungen</p>
  </div>
</section>

<!-- ═══ ABOUT ═══ -->
<section class="section about" id="about" aria-label="Über mich">
  <div class="container">
    <div class="about-grid">
      <div class="about-image reveal">
        <img src="images/natalia-at-work.webp" alt="Natalia Tschischik bei der Arbeit als Hochzeitsfotografin" loading="lazy">
      </div>
      <div class="about-content reveal">
        <span class="section-label">Über mich</span>
        <h2 style="font-style: italic; line-height: 1.4; font-size: clamp(1.4rem, 2.2vw, 2rem);">"Mich interessiert nicht die perfekte Pose. Mich interessiert der Blick, den er dir zuwirft, wenn er denkt, dass niemand hinschaut."</h2>
        <p style="font-size: var(--text-sm); color: var(--brown-400); margin-bottom: 1.5rem;">Natalia Tschischik — Hochzeitsfotografin seit 2012</p>
        <p>
          Mein Ansatz ist dokumentarisches Storytelling. Die schönsten Momente sind die ungeskripteten — die leisen Blicke, die stillen Tränen, die chaotische Freude einer Feier, die sich ganz natürlich entfaltet. Über 200 Paare in Kassel und Nordhessen haben mir ihre Geschichte anvertraut — jede davon einzigartig.
        </p>
        <span class="about-signature">— Natalia</span>
        <div style="margin-top: 1.75rem;">
          <a href="ueber-mich.html" class="album-link">
            Mehr über mich erfahren
            <svg viewBox="0 0 24 24" style="width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ═══ PROCESS ═══ -->
<section class="section process" id="process" aria-label="Ablauf">
  <div class="container">
    <div class="process-header reveal">
      <span class="section-label">3 Schritte zur Buchung</span>
      <h2 class="section-title"><em>Von der ersten Anfrage <br>bis zu euren Hochzeitsfotos.</em></h2>
    </div>
    <div class="process-steps">
      <div class="process-step reveal reveal-delay-1">
        <div class="process-number">01</div>
        <h3>Kennenlernen</h3>
        <p>Schreibt mir eine kurze Nachricht mit eurem Datum und eurer Location. Ich melde mich innerhalb von 24&nbsp;Stunden — versprochen.</p>
      </div>
      <div class="process-step reveal reveal-delay-2">
        <div class="process-number">02</div>
        <h3>Videocall</h3>
        <p>In einem lockeren Videocall (ca.&nbsp;20&nbsp;Min.) lernen wir uns kennen. Ihr erzählt mir von eurem Tag, ich erzähle euch, wie ich arbeite.</p>
      </div>
      <div class="process-step reveal reveal-delay-3">
        <div class="process-number">03</div>
        <h3>Buchung</h3>
        <p>Passt alles? Dann sichert euch euren Termin mit einer Anzahlung. Den Rest regeln wir ganz entspannt per E-Mail.</p>
      </div>
    </div>
  </div>
</section>

<!-- ═══ FAQ ═══ -->
<section class="section faq" id="faq" aria-label="Häufige Fragen">
  <div class="container">
    <div class="faq-header reveal">
      <span class="section-label">Häufige Fragen</span>
      <h2 class="section-title"><em>Häufige Fragen zur <br>Hochzeitsfotografie.</em></h2>
    </div>
    <div class="faq-list">

      <div class="faq-item reveal">
        <button class="faq-question" aria-expanded="false">
          Was kostet eine Hochzeitsreportage?
          <span class="faq-icon" aria-hidden="true"></span>
        </button>
        <div class="faq-answer" role="region">
          <div class="faq-answer-inner">
            Eure Hochzeit ist einzigartig — euer Paket sollte es auch sein. Von der Standesamtbegleitung ab 500&nbsp;€ bis zur ganztägigen Reportage ab 1.400&nbsp;€ gestalte ich alles so, dass es zu eurem Tag passt. Schreibt mir — in einem lockeren Gespräch klären wir den Rest.
          </div>
        </div>
      </div>

      <div class="faq-item reveal">
        <button class="faq-question" aria-expanded="false">
          Wie weit im Voraus sollten wir buchen?
          <span class="faq-icon" aria-hidden="true"></span>
        </button>
        <div class="faq-answer" role="region">
          <div class="faq-answer-inner">
            Je früher, desto besser — besonders für Termine zwischen Mai und Oktober. Viele meiner Paare melden sich 10–14&nbsp;Monate vor der Hochzeit. Aber auch kurzfristige Anfragen sind willkommen, wenn euer Datum noch frei ist. Fragt einfach unverbindlich an — ich sage euch sofort Bescheid.
          </div>
        </div>
      </div>

      <div class="faq-item reveal">
        <button class="faq-question" aria-expanded="false">
          Wann bekommen wir unsere Bilder?
          <span class="faq-icon" aria-hidden="true"></span>
        </button>
        <div class="faq-answer" role="region">
          <div class="faq-answer-inner">
            Innerhalb von 6–8&nbsp;Wochen nach eurer Hochzeit erhaltet ihr eure private Online-Galerie mit allen bearbeiteten Bildern zum Download. Einen Sneak Peek mit den ersten Highlights bekommt ihr innerhalb von 48&nbsp;Stunden — damit ihr die Wartezeit überbrückt und schon mal bei Instagram teilen könnt.
          </div>
        </div>
      </div>

    </div>
    <div style="text-align: center; margin-top: 2.5rem;" class="reveal">
      <a href="faq.html" class="album-link">
        Alle häufigen Fragen
        <svg viewBox="0 0 24 24" style="width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2;"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
    </div>
  </div>
</section>

<!-- ═══ CONTACT ═══ -->
<section class="section contact" id="contact" aria-label="Kontakt">
  <div class="container">
    <div class="contact-inner">
      <div class="contact-left reveal">
        <span class="section-label">Kontakt</span>
        <h2>Schreibt <br>mir.</h2>
        <p class="contact-desc">
          Euer Datum steht? Oder ihr seid noch mitten in der Planung? Egal — schreibt mir einfach. Jede Anfrage ist unverbindlich, und ich antworte innerhalb von 24&nbsp;Stunden. Ich freue mich, eure Geschichte zu hören.
        </p>
        <div class="contact-info">
          <div class="contact-info-item">
            <svg viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2"/><polyline points="22 4 12 13 2 4"/></svg>
            <a href="mailto:natalia@nataliatschischik.com" onclick="if(typeof fbq!=='undefined')fbq('track','Contact',{content_name:'Email'});if(typeof gtag!=='undefined')gtag('event','contact_email',{event_category:'Contact'});if(typeof zaraz!=='undefined')zaraz.track('Contact');">natalia@nataliatschischik.com</a>
          </div>
          <div class="contact-info-item">
            <svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>
            <a href="tel:+4917634948598" onclick="if(typeof fbq!=='undefined')fbq('track','Contact',{content_name:'Telefon'});if(typeof gtag!=='undefined')gtag('event','contact_phone',{event_category:'Contact'});if(typeof zaraz!=='undefined')zaraz.track('Contact');">+49 (0) 176 34 948 598</a>
          </div>
          <div class="contact-info-item">
            <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            <span>Kassel &amp; Göttingen, Deutschland</span>
          </div>
          <div class="contact-info-item">
            <svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 2C6.477 2 2 6.477 2 12c0 1.89.525 3.66 1.438 5.168L2 22l4.832-1.438A9.955 9.955 0 0012 22c5.523 0 10-4.477 10-10S17.523 2 12 2z"/></svg>
            <a href="https://wa.me/4917634948598?text=Hallo%20Natalia%2C%20ich%20interessiere%20mich%20f%C3%BCr%20eure%20Hochzeitsfotografie." target="_blank" rel="noopener noreferrer" onclick="if(typeof fbq!=='undefined')fbq('track','Contact',{content_name:'WhatsApp'});if(typeof gtag!=='undefined')gtag('event','contact_whatsapp',{event_category:'Contact'});if(typeof zaraz!=='undefined')zaraz.track('Contact');">WhatsApp schreiben</a>
          </div>
        </div>
      </div>
      <form class="contact-form reveal" id="contactForm" onsubmit="handleFormSubmit(event)">
        <div class="form-row">
          <div class="form-group">
            <label for="name">Name *</label>
            <input type="text" id="name" name="name" placeholder="Euer Name" required autocomplete="name">
          </div>
          <div class="form-group">
            <label for="email">E-Mail *</label>
            <input type="email" id="email" name="email" placeholder="eure@email.de" required autocomplete="email">
          </div>
        </div>
        <div class="form-group">
          <label for="phone">Telefon</label>
          <input type="tel" id="phone" name="phone" placeholder="+49 ..." autocomplete="tel">
        </div>
        <div class="form-group">
          <label for="message">Eure Nachricht</label>
          <textarea id="message" name="message" placeholder="Erzählt ein bisschen von euch: Wann und wo feiert ihr? Was ist euch bei den Fotos wichtig?"></textarea>
        </div>
        <button type="submit" class="form-submit" id="submitBtn">Anfrage absenden</button>
        <p style="margin-top: 0.75rem; font-size: 0.75rem; color: var(--brown-400); text-align: center; line-height: 1.5;">Unverbindlich &amp; kostenlos · Antwort innerhalb von 24h · 200+ Paare vertrauen mir</p>
        <div id="formStatus" style="margin-top: 1rem; font-size: var(--text-sm); display: none;"></div>
      </form>
    </div>
  </div>
</section>

<!-- ═══ JOURNAL ═══ -->
<section class="section" style="background: var(--cream-light); padding-top: clamp(4rem, 8vw, 7.5rem); padding-bottom: clamp(4rem, 8vw, 7.5rem);">
  <div class="container">
    <div style="text-align: center; margin-bottom: 3rem;" class="reveal">
      <span class="section-label" style="color: var(--accent);">Journal</span>
      <h2 class="section-title" style="font-style: italic;">Wissenswertes für eure Hochzeitsplanung</h2>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
      <!-- Post 1: NEW - Timeline Guide -->
      <div style="position: relative; cursor: pointer;" class="reveal reveal-delay-1" onclick="window.location='/journal/hochzeit-timeline-kassel'">
        <div style="aspect-ratio: 4/5; overflow: hidden; margin-bottom: 1.5rem; background: var(--cream);">
          <img src="images/camera-watercolor.webp" alt="Der perfekte Ablauf — Hochzeit Timeline Guide Kassel" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.7s var(--ease-out);" loading="lazy">
        </div>
        <h3 style="font-family: var(--font-display); font-size: var(--text-xl); color: var(--brown-900); margin-bottom: 0.75rem;"><a href="journal/hochzeit-timeline-kassel.html" style="text-decoration: none; color: inherit;">Der perfekte Ablauf</a></h3>
        <p style="font-family: var(--font-body); font-size: var(--text-sm); color: var(--brown-500); line-height: 1.7; margin-bottom: 1rem;">Euer Wedding-Timeline Guide für Kassel — vom Getting Ready bis zum letzten Tanz.</p>
        <span style="font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.12em; border-bottom: 1px solid var(--brown-200); padding-bottom: 0.25rem;">Weiterlesen</span>
      </div>
      <!-- Post 2: Locations -->
      <div style="position: relative; cursor: pointer;" class="reveal reveal-delay-2" onclick="window.location='/journal/hochzeitslocations-kassel'">
        <div style="aspect-ratio: 4/5; overflow: hidden; margin-bottom: 1.5rem; background: var(--cream);">
          <img src="images/herkules-watercolor.webp" alt="Aquarell-Illustration Bergpark Wilhelmshöhe Kassel" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.7s var(--ease-out);" loading="lazy">
        </div>
        <h3 style="font-family: var(--font-display); font-size: var(--text-xl); color: var(--brown-900); margin-bottom: 0.75rem;"><a href="journal/hochzeitslocations-kassel.html" style="text-decoration: none; color: inherit;">Hochzeitslocations in Kassel</a></h3>
        <p style="font-family: var(--font-body); font-size: var(--text-sm); color: var(--brown-500); line-height: 1.7; margin-bottom: 1rem;">Renthof, Sababurg, Orangerie — welche Location passt zu eurer Hochzeit?</p>
        <span style="font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.12em; border-bottom: 1px solid var(--brown-200); padding-bottom: 0.25rem;">Weiterlesen</span>
      </div>
      <!-- Post 3: Orangerie Kassel -->
      <div style="position: relative; cursor: pointer;" class="reveal reveal-delay-3" onclick="window.location='/journal/orangerie-kassel'">
        <div style="aspect-ratio: 4/5; overflow: hidden; margin-bottom: 1.5rem; background: var(--cream);">
          <img src="images/journal-orangerie-card.webp" alt="Aquarell-Illustration Orangerie Kassel — Hochzeitslocation" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.7s var(--ease-out);" loading="lazy">
        </div>
        <h3 style="font-family: var(--font-display); font-size: var(--text-xl); color: var(--brown-900); margin-bottom: 0.75rem;"><a href="journal/orangerie-kassel.html" style="text-decoration: none; color: inherit;">Hochzeit in der Orangerie</a></h3>
        <p style="font-family: var(--font-body); font-size: var(--text-sm); color: var(--brown-500); line-height: 1.7; margin-bottom: 1rem;">Barocke Eleganz, Karlsaue-Licht und Räume für bis zu 300 Gäste — alles über die Orangerie als Hochzeitslocation.</p>
        <span style="font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.12em; border-bottom: 1px solid var(--brown-200); padding-bottom: 0.25rem;">Weiterlesen</span>
      </div>
    </div>
    <div style="text-align: center; margin-top: 3.5rem;" class="reveal">
      <a href="journal.html" class="btn-ghost">Zum Journal</a>
    </div>
  </div>
</section>

<!-- ═══ FOOTER ═══ -->
<!-- SEO Text Block -->
<section class="seo-footer-text">
  <div class="seo-footer-inner">
    <h2>Hochzeitsfotograf Kassel: Authentische & ungestellte Hochzeitsreportagen</h2>
    <p>Ihr seid auf der Suche nach einem professionellen <strong>Hochzeitsfotograf in Kassel</strong>, der euren großen Tag in emotionalen und echten Bildern festhält? Als erfahrene Hochzeitsfotografin begleite ich verliebte Paare in ganz Nordhessen. Mein Fokus liegt auf der dokumentarischen Hochzeitsfotografie: Ich fange echte Momente, Freudentränen und lautes Lachen ein – ganz ohne künstliche Posen oder steifes Lächeln. Wenn ihr euch natürliche und zeitlose Bilder wünscht, bin ich genau die richtige Wahl für eure <strong>Hochzeitsfotografie in Kassel</strong>.</p>

    <h3>Eure Hochzeitsfotografin für Kassel, Baunatal und Umgebung</h3>
    <p>Ob eine intime standesamtliche Trauung, eine romantische freie Zeremonie im Bergpark Wilhelmshöhe oder ein rauschendes Fest in beliebten Locations wie dem Renthof oder der Orangerie – als lokaler <strong>Fotograf in Kassel</strong> kenne ich die schönsten Orte und besten Lichtverhältnisse für euer Paarshooting. Eine professionelle <strong>Hochzeitsreportage in Kassel</strong> lebt von den kleinen Details am Rand und den großen, überwältigenden Emotionen. Ich begleite euch vom <em>Getting Ready</em> am Morgen bis zum Hochzeitstanz am späten Abend dezent im Hintergrund.</p>

    <h3>Jetzt euren Hochzeitsfotograf Kassel buchen</h3>
    <p>Jede Liebesgeschichte ist einzigartig. Deshalb ist es mir besonders wichtig, dass die Chemie zwischen uns an eurem Hochzeitstag zu 100% stimmt. Stöbert durch mein Portfolio und schreibt mir eine unverbindliche Nachricht, wenn ihr euren <strong>Hochzeitsfotograf Kassel</strong> für die kommende Saison buchen möchtet. Lasst uns gemeinsam Erinnerungen schaffen, die euch ein Leben lang begleiten!</p>
  </div>
</section>

<footer class="footer" role="contentinfo">
  <div class="footer-inner">
    <div>
            <div class="footer-brand">Natalia Tschischik</div>
      <div class="footer-tagline">Hochzeitsfotograf Kassel<br>Göttingen &middot; Nordhessen &middot; Hessen &amp; Niedersachsen</div>
      <address class="footer-nap" style="font-style:normal;margin-top:1rem;font-size:0.75rem;line-height:1.8;color:rgba(196,181,171,0.7);">
        Hochzeitsfotograf Natalia Tschischik<br>
        Harleshäuser Str. 38, 34246 Vellmar<br>
        <a href="tel:+4917634948598" style="color:inherit;">+49 176 34948598</a><br>
        <a href="mailto:natalia@nataliatschischik.com" style="color:inherit;">natalia@nataliatschischik.com</a><br>
        <a href="https://maps.app.goo.gl/ak2VVrbKNQpdYCc16?g_st=ic" target="_blank" rel="noopener" style="color:rgba(196,181,171,0.5);text-decoration:underline;text-underline-offset:3px;">Auf Google Maps ansehen</a>
      </address>
    </div>
    <div class="footer-links">
      <div class="footer-col">
        <h4>Navigation</h4>
        <a href="portfolio.html">Portfolio</a>
        <a href="ueber-mich.html">Über mich</a>
        <a href="preise.html">Preise</a>
        <a href="faq.html">FAQ</a>
    <a href="journal.html">Journal</a>
        <a href="tracking.js.html#contact">Kontakt</a>
      </div>
      <div class="footer-col">
        <h4>Social</h4>
        <a href="https://www.instagram.com/hochzeitsfotografin.natalia/" target="_blank" rel="noopener noreferrer">Instagram</a>
        <a href="tracking.js.html#">Pinterest</a>
      </div>
      <div class="footer-col">
        <h4>Rechtliches</h4>
        <a href="impressum.html">Impressum</a>
        <a href="datenschutz.html">Datenschutz</a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <span class="footer-copy">&copy; 2026 Natalia Tschischik — Hochzeitsfotograf Kassel</span>
    
  </div>
</footer>

<script>
// Scroll-aware nav
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });

// Mobile menu
const hamburger = document.getElementById('hamburger');
const mobileNav = document.getElementById('mobileNav');
hamburger.addEventListener('click', () => {
  const isOpen = mobileNav.classList.toggle('open');
  hamburger.classList.toggle('active');
  hamburger.setAttribute('aria-label', isOpen ? 'Menü schließen' : 'Menü öffnen');
  document.body.style.overflow = isOpen ? 'hidden' : '';
});
function closeMobile() {
  mobileNav.classList.remove('open');
  hamburger.classList.remove('active');
  hamburger.setAttribute('aria-label', 'Menü öffnen');
  document.body.style.overflow = '';
}

// FAQ Accordion
document.querySelectorAll('.faq-question').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.parentElement;
    const answer = item.querySelector('.faq-answer');
    const isOpen = item.classList.contains('open');
    
    // Close all others
    document.querySelectorAll('.faq-item.open').forEach(openItem => {
      if (openItem !== item) {
        openItem.classList.remove('open');
        openItem.querySelector('.faq-answer').style.maxHeight = '0';
        openItem.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      }
    });
    
    // Toggle current
    item.classList.toggle('open');
    btn.setAttribute('aria-expanded', !isOpen);
    if (!isOpen) {
      answer.style.maxHeight = answer.scrollHeight + 'px';
    } else {
      answer.style.maxHeight = '0';
    }
  });
});

// Reveal on scroll
const reveals = document.querySelectorAll('.reveal');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
reveals.forEach(el => observer.observe(el));

// ═══ CONTACT FORM — WhatsApp via Cloudflare Pages Function ═══
async function handleFormSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('submitBtn');
  const status = document.getElementById('formStatus');
  const form = document.getElementById('contactForm');

  const name = form.querySelector('#name').value.trim();
  const email = form.querySelector('#email').value.trim();
  const phone = form.querySelector('#phone').value.trim();
  const message = form.querySelector('#message').value.trim();
  const date = ''; // removed from form, may be in message
  const location = ''; // removed from form, may be in message

  if (!name || !email) return;

  btn.disabled = true;
  btn.textContent = 'Wird gesendet...';
  btn.style.opacity = '0.6';
  status.style.display = 'none';

  try {
    // Collect Meta + Google click IDs for server-side tracking
    const fbclid = new URLSearchParams(window.location.search).get('fbclid') || '';
    const fbpMatch = document.cookie.match(/(?:^|;\s*)_fbp=([^;]*)/);
    const fbcMatch = document.cookie.match(/(?:^|;\s*)_fbc=([^;]*)/);
    const gclidMatch = document.cookie.match(/(?:^|;\s*)_gclid=([^;]*)/);
    const attrMatch = document.cookie.match(/(?:^|;\s*)_attribution=([^;]*)/);
    const fbp = fbpMatch ? fbpMatch[1] : '';
    const fbc = fbcMatch ? fbcMatch[1] : '';
    const gclid = gclidMatch ? gclidMatch[1] : '';
    const attribution = attrMatch ? decodeURIComponent(attrMatch[1]) : '';
    const eventID = 'lead_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);

    const res = await fetch('https://natalia-form-handler.icy-sunset-af0f.workers.dev', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone, date, location, message, fbclid, fbp, fbc, gclid, attribution, event_id: eventID, source_url: window.location.href }),
    });
    const result = await res.json();

    if (res.ok && result.success) {
      // Track Lead conversion with Advanced Matching + Deduplication
      if (typeof fbq !== 'undefined') {
        // Parse name for Advanced Matching
        var cleanName = name.replace(/\s+(und|&|\+)\s+/gi, '|');
        var people = cleanName.split('|').map(function(n) { return n.trim().split(/\s+/); });
        var userData = {em: email.toLowerCase()};
        if (phone) userData.ph = phone.replace(/[^0-9]/g, '');
        if (people[0] && people[0][0]) userData.fn = people[0][0].toLowerCase();
        if (people[0] && people[0][1]) userData.ln = people[0][1].toLowerCase();
        // Re-init with user data for Advanced Matching
        fbq('init', '1083293176093427', userData);
        // Single Lead event with eventID for deduplication with CAPI
        fbq('track', 'Lead', {content_name: 'Kontaktformular', content_category: 'Hochzeitsfotografie', value: 1.00, currency: 'EUR'}, {eventID: eventID});
      }
      if (typeof zaraz !== 'undefined') zaraz.track('Lead');
      // GA4 Lead event (importable as Google Ads conversion)
      if (typeof gtag !== 'undefined') {
        // Enhanced Conversions: send hashed user data to Google
        gtag('set', 'user_data', {
          'email': email.toLowerCase().trim(),
          'phone_number': phone ? phone.replace(/[^0-9+]/g, '') : undefined
        });
        gtag('event', 'generate_lead', {
          event_category: 'Contact',
          event_label: 'Kontaktformular',
          value: 150,
          currency: 'EUR',
          transaction_id: 'lead_' + Date.now()
        });
      }
      showStatus('\u2705 Vielen Dank! Eure Anfrage wurde gesendet. Natalia meldet sich innerhalb von 24 Stunden.', 'var(--accent)');
      form.reset();
    } else {
      showStatus('\u274C Es gab ein Problem beim Senden. Bitte versucht es erneut oder schreibt direkt an natalia@nataliatschischik.com', '#c0392b');
    }
  } catch (err) {
    showStatus('\u274C Verbindungsfehler. Bitte versucht es erneut oder schreibt direkt an natalia@nataliatschischik.com', '#c0392b');
  }

  btn.disabled = false;
  btn.textContent = 'Anfrage absenden';
  btn.style.opacity = '1';
}

function showStatus(msg, color) {
  const status = document.getElementById('formStatus');
  status.textContent = msg;
  status.style.color = color;
  status.style.display = 'block';
}
</script>

<script>
// Track scroll depth & engagement for Meta Pixel + GA4
(function() {
  var scrollTracked = {};
  window.addEventListener('scroll', function() {
    var pct = Math.round(100 * window.scrollY / (document.body.scrollHeight - window.innerHeight));
    [25, 50, 75, 100].forEach(function(t) {
      if (pct >= t && !scrollTracked[t]) {
        scrollTracked[t] = true;
        if (typeof gtag !== 'undefined') gtag('event', 'scroll_depth', {event_category: 'Engagement', event_label: t + '%'});
        if (typeof zaraz !== 'undefined') zaraz.track('Scroll Depth ' + t);
      }
    });
  });
  // Track time on page
  setTimeout(function() {
    if (typeof gtag !== 'undefined') gtag('event', 'engaged_visit', {event_category: 'Engagement', event_label: '30s'});
    if (typeof fbq !== 'undefined') fbq('trackCustom', 'EngagedVisit', {duration: '30s'});
    if (typeof zaraz !== 'undefined') zaraz.track('EngagedVisit');
  }, 30000);
  // Track CTA button clicks
  document.querySelectorAll('.btn-primary, .nav-cta, .mobile-cta').forEach(function(el) {
    el.addEventListener('click', function() {
      if (typeof fbq !== 'undefined') fbq('track', 'InitiateCheckout', {content_name: 'CTA Click'});
      if (typeof gtag !== 'undefined') gtag('event', 'cta_click', {event_category: 'Conversion', event_label: el.textContent.trim()});
      if (typeof zaraz !== 'undefined') zaraz.track('Contact');
    });
  });
  // Track portfolio link clicks
  document.querySelectorAll('.portfolio-item a, a[href*="portfolio"], a[href*="reportagen"]').forEach(function(el) {
    el.addEventListener('click', function() {
      if (typeof fbq !== 'undefined') fbq('track', 'ViewContent', {content_name: 'Portfolio', content_type: 'product'});
      if (typeof gtag !== 'undefined') gtag('event', 'view_portfolio', {event_category: 'Engagement'});
      if (typeof zaraz !== 'undefined') zaraz.track('ViewContent');
    });
  });
})();
</script>

<script>
// City rotation in H1: Kassel → others → back to Kassel
(function() {
  var cities = ['Kassel', 'G\u00f6ttingen', 'Marburg', 'Gie\u00dfen', 'Waldeck', 'Frankenberg', 'Fulda', 'Hessen'];
  var el = document.getElementById('city-rotate');
  if (!el) return;
  var i = 0;
  var interval = setInterval(function() {
    i++;
    if (i >= cities.length) { clearInterval(interval); return; }
    el.style.opacity = '0';
    setTimeout(function() {
      el.textContent = cities[i];
      el.style.opacity = '1';
    }, 400);
  }, 1200);
})();
</script>

<style>
#city-rotate {
  display: inline-block;
  min-width: 5ch;
  transition: opacity 0.4s ease;
}

/* ═══ SEO FOOTER TEXT ═══ */
.seo-footer-text {
  background: var(--cream-light, #FAF8F4);
  border-top: 1px solid var(--cream-dark, #EDE7DB);
  padding: clamp(3rem, 6vw, 5rem) clamp(1.5rem, 4vw, 2rem);
}
.seo-footer-inner {
  max-width: 760px;
  margin: 0 auto;
}
.seo-footer-text h2 {
  font-family: var(--font-display, 'Cormorant Garamond', serif);
  font-size: clamp(1.3rem, 2.5vw, 1.6rem);
  font-weight: 400;
  letter-spacing: 0.01em;
  color: var(--brown-800, #3D2518);
  margin-bottom: 1.25rem;
  line-height: 1.35;
}
.seo-footer-text h3 {
  font-family: var(--font-display, 'Cormorant Garamond', serif);
  font-size: clamp(1.05rem, 2vw, 1.2rem);
  font-weight: 400;
  letter-spacing: 0.01em;
  color: var(--brown-700, #4A3228);
  margin-top: 2rem;
  margin-bottom: 0.75rem;
  line-height: 1.4;
}
.seo-footer-text p {
  font-family: var(--font-body, 'DM Sans', sans-serif);
  font-size: 0.875rem;
  line-height: 1.85;
  color: var(--brown-500, #7A6258);
  margin-bottom: 0;
}
.seo-footer-text p + p {
  margin-top: 1rem;
}
.seo-footer-text strong {
  color: var(--brown-600, #5E443A);
  font-weight: 500;
}
.seo-footer-text em {
  font-style: italic;
}
</style>

<script>
// Fix anchor scroll after lazy images load
if (window.location.hash) {
  window.addEventListener('load', function() {
    setTimeout(function() {
      var el = document.querySelector(window.location.hash);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 300);
  });
}
</script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"086648f4cb124d5489b8acf9734352f3","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script src="js/tracking.js" defer></script>
</body>
<!-- deploy-v1774636094 -->
<!-- build-1775217074 -->
</html>
<!-- v1774633366 -->
<!-- FRESH-1775215819-b5c383e2 -->
